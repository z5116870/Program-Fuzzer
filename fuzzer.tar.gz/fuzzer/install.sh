#!/bin/sh

sudo apt-get install python3-magic
pip3 install xmljson
pip3 install exif
pip3 install PyPDF2
pip3 install makeelf
pip3 install beautifulsoup4
pip3 install Pillow

pip install xmljson
pip install exif
pip install PyPDF2
pip install makeelf
pip install beautifulsoup4
pip install Pillow
