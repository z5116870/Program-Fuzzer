def init(delimiter):
    global CSV_DELIMITER
    CSV_DELIMITER = delimiter